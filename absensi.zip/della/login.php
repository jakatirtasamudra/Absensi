<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>
        Login | <?= nama_url(); ?>
    </title>

    <!-- Google Font: Source Sans Pro -->
    <link rel="stylesheet"
        href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="<?= base_url(); ?>assets/plugins/fontawesome-free/css/all.min.css">
    <!-- icheck bootstrap -->
    <link rel="stylesheet" href="<?= base_url(); ?>assets/plugins/icheck-bootstrap/icheck-bootstrap.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="<?= base_url(); ?>assets/dist/css/adminlte.min.css">
</head>

<body class="hold-transition login-page">


    <div class="login-box">
        <div class="login-logo">
            <a href="<?= base_url(); ?>">
                <b>
                    Login
                </b>
            </a>
        </div>
        <div class="card">
            <div class="card-body login-card-body">
                <p class="login-box-msg">
                    Silahkan Login Terlebih Dahulu
                </p>
                <form action="" method="POST" enctype="multipart/form-data">
                    <div class="input-group mb-3">
                        <input type="text" class="form-control" placeholder="Username" name="Username"
                            autocomplete="off" required>
                        <div class="input-group-append">
                            <div class="input-group-text">
                                <span class="fas fa-users"></span>
                            </div>
                        </div>
                    </div>
                    <div class="input-group mb-3">
                        <input type="password" class="form-control" placeholder="Password" name="Password"
                            autocomplete="off" required>
                        <div class="input-group-append">
                            <div class="input-group-text">
                                <span class="fas fa-lock"></span>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-12">
                            <button type="submit" class="btn btn-primary btn-block" name="Login">
                                Login
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>


    <!-- jQuery -->
    <script src="<?= base_url(); ?>assets/plugins/jquery/jquery.min.js"></script>
    <!-- Bootstrap 4 -->
    <script src="<?= base_url(); ?>assets/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
    <!-- AdminLTE App -->
    <script src="<?= base_url(); ?>assets/dist/js/adminlte.min.js"></script>
</body>

</html>





<?php

    if ( isset ( $_POST['Login'] ) ) {

        if ( @$_POST['Username'] == TRUE AND @$_POST['Password'] ) {

            @$session_admin = queryid (" SELECT Id FROM Tbl_Login WHERE Username = '". @$_POST['Username'] ."' AND Password = '". @$_POST['Password'] ."' ORDER BY Id DESC ");

            @$session_pegawai = queryid (" SELECT Id FROM Tbl_Pegawai WHERE Username = '". @$_POST['Username'] ."' AND Password = '". @$_POST['Password'] ."' ORDER BY Id DESC ");

            if ( @$session_admin->Id == TRUE ) {

                @$_SESSION['Id']        = @$session_admin->Id;
                @$_SESSION['Status']    = 'Admin';

                echo "<script>
                        alert('Selamat Datang !');
                        document.location.href = '". base_url() ."';
                    </script>";

            } elseif ( @$session_pegawai->Id == TRUE ) {

                @$_SESSION['Id']        = @$session_pegawai->Id;
                @$_SESSION['Status']    = 'Pegawai';

                echo "<script>
                        alert('Selamat Datang !');
                        document.location.href = '". base_url() ."';
                    </script>";

            } else {

                echo "<script>
                        alert('Akun Yang Di Isi Tidak Terdaftar');
                        document.location.href = '". base_url() ."';
                    </script>";

            }

        } else {

            echo "<script>
                    alert('Silahkan Isi Form Login');
                    document.location.href = '". base_url() ."';
                </script>";

        }

    }

?>