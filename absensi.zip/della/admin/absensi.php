<div class="content-wrapper">
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>
                        Beranda
                    </h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item">
                            <a href="<?= base_url(); ?>">
                                Beranda
                            </a>
                        </li>
                        <li class="breadcrumb-item">
                            <a href="<?= base_url(); ?>?Mod=Absensi">
                                Data Absensi
                            </a>
                        </li>
                        <li class="breadcrumb-item active">
                            Absensi
                        </li>
                    </ol>
                </div>
            </div>
        </div>
    </section>
    <section class="content">
        <div class="card">
            <div class="card-header">
                <form action="" method="POST" enctype="multipart/form-data">
                    <a href="?Mod=Absensi&F=M" class="btn btn-primary ml-auto" name="FilterMasuk">
                        Absensi Masuk
                    </a>
                    <a href="?Mod=Absensi&F=P" class="btn btn-info ml-auto" name="FilterPulang">
                        Absensi Pulang
                    </a>
                </form>
            </div>

            <?php if ( isset ( $_POST['FilterMasuk'] ) OR isset ( $_POST['FilterPulang'] ) OR isset ( $_POST['Cari'] ) OR @$_GET['F'] == TRUE ) { ?>

            <div class="card-header">
                <form action="" method="POST" enctype="multipart/form-data">
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12">
                            <div class="form-group">
                                <h2 class="text-center">
                                    <?php if ( @$_GET['F'] == 'M' ) { @$ket = 'In'; ?>
                                    Absensi Masuk
                                    <?php } elseif ( @$_GET['F'] == 'P' ) { @$ket = 'Out'; ?>
                                    Absensi Pulang
                                    <?php } elseif ( isset ( $_POST['FilterMasuk'] ) OR isset ( $_POST['Cari'] ) ) { @$ket = 'In'; ?>
                                    Absensi Masuk
                                    <?php } elseif ( isset ( $_POST['FilterPulang'] ) OR isset ( $_POST['Cari'] ) ) { @$ket = 'Out'; ?>
                                    Absensi Pulang
                                    <?php } ?>
                                </h2>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-3 col-sm-12">
                            <div class="form-group">
                                <input type="date" class="form-control" placeholder="Tanggal Absen"
                                    value="<?= @$_POST['Tgl']; ?>" autocomplete="off" name="Tgl" required>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-3 col-sm-12">
                            <div class="form-group">
                                <button type="submit" class="btn btn-success ml-auto" name="Cari">
                                    Cari
                                </button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
            <div class="card-body">
                <table id="example1" class="table table-bordered table-striped text-center">
                    <thead class="bg-warning">
                        <tr>
                            <th>Nomor</th>
                            <th>Barcode</th>
                            <th>Tanggal</th>
                            <th>Jam</th>
                            <th>Keterangan</th>
                            <th>Nama Lengkap</th>
                            <th>Jabatan</th>
                            <th>Divisi</th>
                            <th>Perintah</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                            @$nomor = '1';
                            @$request_data = query (" SELECT * FROM Tbl_Absensi WHERE Tgl = '". @$_POST['Tgl'] ."' AND Ket = '". @$ket ."' ORDER BY Id DESC ");
                                foreach ( $request_data AS $data => $request ) :

                                    @$pegawai = queryid (" SELECT * FROM Tbl_Pegawai ORDER BY Id DESC ");
                        ?>
                        <tr>
                            <td>
                                <?= @$nomor++; ?>
                            </td>
                            <td>
                                <img src="<?= base_url(); ?>barcode/<?= @$request->Barcode; ?>.png" class="w-50">
                            </td>
                            <td>
                                <?= @$request->Tgl; ?>
                            </td>
                            <td>
                                <?= @$request->Jam; ?>
                            </td>
                            <td>
                                <?= @$request->Ket; ?>
                            </td>
                            <td>
                                <?= @$pegawai->Nama; ?>
                            </td>
                            <td>
                                <?= @$pegawai->Jabatan; ?>
                            </td>
                            <td>
                                <?= @$pegawai->Divisi; ?>
                            </td>
                            <td>
                                <!-- <a href="?Mod=MasterTambah&Id=<?= @$request->Id; ?>" class="btn btn-success btn-sm">
                                    <i class="fa fa-edit"></i>
                                </a> -->
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <?php } ?>

        </div>
    </section>
</div>