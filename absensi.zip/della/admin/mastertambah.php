<?php 

    if ( @$_GET['Id'] == TRUE ) {

        @$session_update = queryid (" SELECT * FROM Tbl_Pegawai WHERE Id = '". @$_GET['Id'] ."' ORDER BY Id DESC ");

    }

?>


<div class="content-wrapper">
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>
                        Beranda
                    </h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item">
                            <a href="<?= base_url(); ?>">
                                Beranda
                            </a>
                        </li>
                        <li class="breadcrumb-item">
                            <a href="<?= base_url(); ?>?Mod=Master">
                                Data Master
                            </a>
                        </li>
                        <?php if ( @$session_update->Id == TRUE ) {?>
                        <li class="breadcrumb-item">
                            <a href="<?= base_url(); ?>?Mod=MasterTambah&Id=<?= @$session_update->Id; ?>">
                                Ubah Master
                            </a>
                        </li>
                        <li class="breadcrumb-item active">
                            Ubah
                        </li>
                        <?php } else { ?>
                        <li class="breadcrumb-item">
                            <a href="<?= base_url(); ?>?Mod=MasterTambah">
                                Tambah Master
                            </a>
                        </li>
                        <li class="breadcrumb-item active">
                            Tambah
                        </li>
                        <?php  } ?>
                    </ol>
                </div>
            </div>
        </div>
    </section>
    <section class="content">
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">
                    Data Master
                </h3>
                <a href="?Mod=Master" class="btn btn-danger ml-auto float-right">
                    Kembali
                </a>
            </div>
            <div class="card-body">
                <form action="" method="POST" enctype="multipart/form-data">

                    <?php if ( @$session_update->Id == TRUE ) {?>

                    <input type="hidden" class="form-control" placeholder="Nama Lengkap"
                        value="<?= @$session_update->Id; ?>" autocomplete="off" name="Id" required>

                    <?php } ?>

                    <div class="row">
                        <div class="col-lg-6 col-md-6 col-sm-12">
                            <div class="form-group">
                                <label for="exampleInputEmail1">
                                    Nama Lengkap
                                </label>
                                <input type="text" class="form-control" placeholder="Nama Lengkap"
                                    value="<?= @$session_update->Nama; ?>" autocomplete="off" name="Nama" required>
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-6 col-sm-12">
                            <div class="form-group">
                                <label for="exampleInputEmail1">
                                    Email
                                </label>
                                <input type="email" class="form-control" placeholder="Email"
                                    value="<?= @$session_update->Email; ?>" autocomplete="off" name="Email" required>
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-6 col-sm-12">
                            <div class="form-group">
                                <label for="exampleInputEmail1">
                                    Tempat Tanggal Lahir
                                </label>
                                <input type="text" class="form-control" placeholder="Tempat Tanggal Lahir"
                                    value="<?= @$session_update->TempatLahir; ?>" autocomplete="off" name="TempatLahir"
                                    required>
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-6 col-sm-12">
                            <div class="form-group">
                                <label for="exampleInputEmail1">
                                    Tanggal Lahir
                                </label>
                                <input type="date" class="form-control" placeholder="Tanggal Lahir"
                                    value="<?= @$session_update->TglLahir; ?>" autocomplete="off" name="TglLahir"
                                    required>
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-6 col-sm-12">
                            <div class="form-group">
                                <label for="exampleInputEmail1">
                                    Username
                                </label>
                                <input type="text" class="form-control" placeholder="Username"
                                    value="<?= @$session_update->Username; ?>" autocomplete="off" name="Username"
                                    required>
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-6 col-sm-12">
                            <div class="form-group">
                                <label for="exampleInputEmail1">
                                    Password
                                </label>
                                <input type="text" class="form-control" placeholder="Password"
                                    value="<?= @$session_update->Password; ?>" autocomplete="off" name="Password"
                                    required>
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-6 col-sm-12">
                            <div class="form-group">
                                <label for="exampleInputEmail1">
                                    Jabatan
                                </label>
                                <input type="text" class="form-control" placeholder="Jabatan"
                                    value="<?= @$session_update->Jabatan; ?>" autocomplete="off" name="Jabatan"
                                    required>
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-6 col-sm-12">
                            <div class="form-group">
                                <label for="exampleInputEmail1">
                                    Divisi
                                </label>
                                <input type="text" class="form-control" placeholder="Divisi"
                                    value="<?= @$session_update->Divisi; ?>" autocomplete="off" name="Divisi" required>
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-6 col-sm-12">
                            <div class="form-group">
                                <label for="exampleInputEmail1">
                                    Tahun Masuk
                                </label>
                                <input type="date" class="form-control" placeholder="Tahun Masuk"
                                    value="<?= @$session_update->TglMasuk; ?>" autocomplete="off" name="TglMasuk"
                                    required>
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-6 col-sm-12">
                            <div class="form-group">
                                <label for="exampleInputEmail1">
                                    Status
                                </label>
                                <select name="Status" class="form-control" required>
                                    <?php if ( @$session_update->Id == TRUE ) {?>
                                    <option value="<?= @$session_update->Status; ?>" selected>
                                        <?php 
                                            if ( @$session_update->Status == 'Y' ) {
                                                echo 'Aktif';
                                            } else {
                                                echo 'Tidak Aktif';
                                            }
                                        ?>
                                    </option>
                                    <option value="" disabled>
                                        --- ##### ---
                                    </option>
                                    <?php } else { ?>
                                    <option value="" selected disabled>
                                        --- Pilih Status ---
                                    </option>
                                    <?php } ?>
                                    <option value="Y">
                                        Aktif
                                    </option>
                                    <option value="T">
                                        Tidak Aktif
                                    </option>
                                </select>
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-6 col-sm-12">
                            <?php if ( @$session_update->Id == TRUE ) {?>
                            <button type="submit" class="btn btn-primary" name="BtnUbahMaster">
                                Ubah
                            </button>
                            <?php } else { ?>
                            <button type="submit" class="btn btn-primary" name="BtnSimpanMaster">
                                Simpan
                            </button>
                            <?php } ?>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </section>
</div>




<?php

    if ( isset ( $_POST['BtnSimpanMaster'] ) ) {

        if ( @$_POST['Nama'] == TRUE AND @$_POST['Email'] == TRUE AND @$_POST['Username'] == TRUE AND @$_POST['Password'] == TRUE AND @$_POST['Jabatan'] == TRUE AND @$_POST['Divisi'] == TRUE AND @$_POST['TempatLahir'] == TRUE AND @$_POST['TglLahir'] == TRUE AND @$_POST['Status'] == TRUE AND @$_POST['TglMasuk'] == TRUE ) {

            @$username = queryid (" SELECT Id FROM Tbl_Pegawai WHERE Username = '". @$_POST['Username'] ."' ORDER BY Id DESC ");

            if ( @$username->Id == TRUE ) {

                echo "<script>
                        alert('Username Telah Terdaftar');
                        document.location.href = '". base_url() ."?Mod=MasterTambah';
                    </script>";

            } else {

                @$email = queryid (" SELECT Id FROM Tbl_Pegawai WHERE Email = '". @$_POST['Email'] ."' ORDER BY Id DESC ");

                if ( @$email->Id == TRUE ) {

                    echo "<script>
                            alert('Email Telah Terdaftar');
                            document.location.href = '". base_url() ."?Mod=MasterTambah';
                        </script>";

                } else {

                    @$datas = [
                        'Nama'          => @$_POST['Nama'],
                        'Email'         => @$_POST['Email'],
                        'Username'      => @$_POST['Username'],
                        'Password'      => @$_POST['Password'],
                        'Jabatan'       => @$_POST['Jabatan'],
                        'Divisi'        => @$_POST['Divisi'],
                        'TempatLahir'   => @$_POST['TempatLahir'],
                        'TglLahir'      => @$_POST['TglLahir'],
                        'Status'        => @$_POST['Status'],
                        'TglMasuk'      => @$_POST['TglMasuk'],
                    ];

                    @$query_action = Query_Master ( @$datas, 'Insert' );

                    if ( @$query_action == '200' ) {

                        echo "<script>
                                alert('Sukses !');
                                document.location.href = '". base_url() ."?Mod=Master';
                            </script>";

                    } else {

                        echo "<script>
                                alert('Terjadi Error');
                                document.location.href = '". base_url() ."?Mod=MasterTambah';
                            </script>";

                    }

                }

            }

        } else {

            echo "<script>
                    alert('Isi Form Dengan Benar');
                    document.location.href = '". base_url() ."?Mod=MasterTambah';
                </script>";

        }

    } elseif ( isset ( $_POST['BtnUbahMaster'] ) ) {

        if ( @$_POST['Id'] == TRUE AND @$_POST['Nama'] == TRUE AND @$_POST['Email'] == TRUE AND @$_POST['Username'] == TRUE AND @$_POST['Password'] == TRUE AND @$_POST['Jabatan'] == TRUE AND @$_POST['Divisi'] == TRUE AND @$_POST['TempatLahir'] == TRUE AND @$_POST['TglLahir'] == TRUE AND @$_POST['Status'] == TRUE AND @$_POST['TglMasuk'] == TRUE ) {

            @$pegawai = queryid (" SELECT Id FROM Tbl_Pegawai WHERE Id = '". @$_POST['Id'] ."' ORDER BY Id DESC ");

            if ( @$pegawai->Id == TRUE ) {

                @$username = queryid (" SELECT Id FROM Tbl_Pegawai WHERE Username = '". @$_POST['Username'] ."' AND NOT Id = '". @$_POST['Id'] ."' ORDER BY Id DESC ");

                if ( @$username->Id == TRUE ) {

                    echo "<script>
                            alert('Username Telah Terdaftar');
                            document.location.href = '". base_url() ."?Mod=MasterTambah&Id=". @$_GET['Id'] ."';
                        </script>";

                } else {

                    @$email = queryid (" SELECT Id FROM Tbl_Pegawai WHERE Email = '". @$_POST['Email'] ."' AND NOT Id = '". @$_POST['Id'] ."' ORDER BY Id DESC ");

                    if ( @$email->Id == TRUE ) {

                        echo "<script>
                                alert('Email Telah Terdaftar');
                                document.location.href = '". base_url() ."?Mod=MasterTambah&Id=". @$_GET['Id'] ."';
                            </script>";

                    } else {

                        @$datas = [
                            'Id'            => @$pegawai->Id,
                            'Nama'          => @$_POST['Nama'],
                            'Email'         => @$_POST['Email'],
                            'Username'      => @$_POST['Username'],
                            'Password'      => @$_POST['Password'],
                            'Jabatan'       => @$_POST['Jabatan'],
                            'Divisi'        => @$_POST['Divisi'],
                            'TempatLahir'   => @$_POST['TempatLahir'],
                            'TglLahir'      => @$_POST['TglLahir'],
                            'Status'        => @$_POST['Status'],
                            'TglMasuk'      => @$_POST['TglMasuk'],
                        ];

                        @$query_action = Query_Master ( @$datas, 'Update' );

                        if ( @$query_action == '200' ) {

                            echo "<script>
                                    alert('Sukses !');
                                    document.location.href = '". base_url() ."?Mod=Master';
                                </script>";

                        } else {

                            echo "<script>
                                    alert('Terjadi Error');
                                    document.location.href = '". base_url() ."?Mod=MasterTambah&Id=". @$_GET['Id'] ."';
                                </script>";

                        }

                    }

                }

            } else {

                echo "<script>
                        alert('Data Pegawai Tidak Ada');
                        document.location.href = '". base_url() ."?Mod=MasterTambah&Id=". @$_GET['Id'] ."';
                    </script>";

            }

        } else {

            echo "<script>
                    alert('Isi Form Dengan Benar');
                    document.location.href = '". base_url() ."?Mod=MasterTambah&Id=". @$_GET['Id'] ."';
                </script>";

        }

    }

?>