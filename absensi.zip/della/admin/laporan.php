<div class="content-wrapper">
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>
                        Beranda
                    </h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item">
                            <a href="<?= base_url(); ?>">
                                Beranda
                            </a>
                        </li>
                        <li class="breadcrumb-item">
                            <a href="<?= base_url(); ?>?Mod=Laporan">
                                Data Laporan
                            </a>
                        </li>
                        <li class="breadcrumb-item active">
                            Laporan
                        </li>
                    </ol>
                </div>
            </div>
        </div>
    </section>
    <section class="content">
        <div class="card">



            <div class="card-header">
                <form action="" method="POST" enctype="multipart/form-data">
                    <div class="row">
                        <div class="col-lg-3 col-md-3 col-sm-12">
                            <div class="form-group">
                                <input type="date" class="form-control" placeholder="Tanggal Absen"
                                    value="<?= @$_POST['Tgl']; ?>" autocomplete="off" name="Tgl" required>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-3 col-sm-12">
                            <div class="form-group">
                                <button type="submit" class="btn btn-success ml-auto" name="Cari">
                                    Cari
                                </button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>

            <?php if ( isset ( $_POST['Cari'] ) ) { ?>

            <div class="card-body">
                <table id="example1" class="table table-bordered table-striped text-center">
                    <thead class="bg-warning">
                        <tr>
                            <th>Nomor</th>
                            <th>Barcode</th>
                            <th>Tanggal</th>
                            <th>Jam</th>
                            <th>Keterangan</th>
                            <th>Nama Lengkap</th>
                            <th>Jabatan</th>
                            <th>Divisi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                            @$nomor = '1';
                            @$request_data = query (" SELECT * FROM Tbl_Absensi WHERE Tgl = '". @$_POST['Tgl'] ."' ORDER BY Id DESC ");
                                foreach ( $request_data AS $data => $request ) :

                                    @$pegawai = queryid (" SELECT * FROM Tbl_Pegawai ORDER BY Id DESC ");
                        ?>
                        <tr>
                            <td>
                                <?= @$nomor++; ?>
                            </td>
                            <td>
                                <img src="<?= base_url(); ?>barcode/<?= @$request->Barcode; ?>.png" class="w-50">
                            </td>
                            <td>
                                <?= @$request->Tgl; ?>
                            </td>
                            <td>
                                <?= @$request->Jam; ?>
                            </td>
                            <td>
                                <?= @$request->Ket; ?>
                            </td>
                            <td>
                                <?= @$pegawai->Nama; ?>
                            </td>
                            <td>
                                <?= @$pegawai->Jabatan; ?>
                            </td>
                            <td>
                                <?= @$pegawai->Divisi; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <?php } ?>

        </div>
    </section>
</div>