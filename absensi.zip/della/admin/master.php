<?php


    if ( @$_GET['Path'] == TRUE AND @$_GET['Id'] == TRUE ) {

        if ( @$_GET['Path'] == 'Hapus' ) {

            @$pegawai = queryid (" SELECT Id FROM Tbl_Pegawai WHERE Id = '". @$_GET['Id'] ."' ORDER BY Id DESC ");

            if ( @$pegawai->Id == TRUE ) {

                @$datas = [
                    'Id'            => @$pegawai->Id,
                ];

                @$query_action = Query_Master ( @$datas, 'Delete' );

                if ( @$query_action == '200' ) {

                    echo "<script>
                            alert('Sukses !');
                            document.location.href = '". base_url() ."?Mod=Master';
                        </script>";

                } else {

                    echo "<script>
                            alert('Terjadi Error');
                            document.location.href = '". base_url() ."?Mod=Master';
                        </script>";

                }

            } else {

                echo "<script>
                    alert('Data Pegawai Tidak Ada');
                    document.location.href = '". base_url() ."?Mod=Master';
                </script>";

            }

        }

    }


?>



<div class="content-wrapper">
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>
                        Beranda
                    </h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item">
                            <a href="<?= base_url(); ?>">
                                Beranda
                            </a>
                        </li>
                        <li class="breadcrumb-item">
                            <a href="<?= base_url(); ?>?Mod=Master">
                                Data Master
                            </a>
                        </li>
                        <li class="breadcrumb-item active">
                            Master
                        </li>
                    </ol>
                </div>
            </div>
        </div>
    </section>
    <section class="content">
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">
                    Data Master
                </h3>
                <a href="?Mod=MasterTambah" class="btn btn-primary ml-auto float-right">
                    Tambah Data
                </a>
            </div>
            <div class="card-body">
                <table id="example1" class="table table-bordered table-striped text-center">
                    <thead class="bg-warning">
                        <tr>
                            <th>Nomor</th>
                            <th>Nama Lengkap</th>
                            <th>Tgl Lahir</th>
                            <th>Email</th>
                            <th>Jabatan</th>
                            <th>Divisi</th>
                            <th>Tgl Masuk</th>
                            <th>Status</th>
                            <th>Perintah</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                            @$nomor = '1';
                            @$request_data = query (" SELECT * FROM Tbl_Pegawai ORDER BY Id DESC ");
                                foreach ( @$request_data AS $data => $request ) :
                        ?>
                        <tr>
                            <td>
                                <?= @$nomor++; ?>
                            </td>
                            <td>
                                <?= @$request->Nama; ?>
                            </td>
                            <td>
                                <?= @$request->TempatLahir; ?>, <?= @$request->TglLahir; ?>
                            </td>
                            <td>
                                <?= @$request->Email; ?>
                            </td>
                            <td>
                                <?= @$request->Jabatan; ?>
                            </td>
                            <td>
                                <?= @$request->Divisi; ?>
                            </td>
                            <td>
                                <?= @$request->TglMasuk; ?>
                            </td>
                            <td>
                                <?php 
                                    if ( @$request->Status == 'Y' ) {
                                        echo 'Aktif';
                                    } else {
                                        echo 'Tidak Aktif';
                                    }
                                ?>
                            </td>
                            <td>
                                <a href="?Mod=MasterTambah&Id=<?= @$request->Id; ?>" class="btn btn-success btn-sm">
                                    <i class="fa fa-edit"></i>
                                </a>
                                <?php if ( @$request->Status != 'Y' ) { ?>
                                <a href="?Mod=Master&Path=Hapus&Id=<?= @$request->Id; ?>" class="btn btn-danger btn-sm">
                                    <i class="fa fa-trash"></i>
                                </a>
                                <?php } ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </section>
</div>