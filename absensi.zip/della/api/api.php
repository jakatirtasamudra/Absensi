<?php



    require_once dirname(__DIR__) . '/base.php';

    
    header('Access-Control-Allow-Origin: *');
    header('Content-Type: application/json');

    
    // function Api_Curl ( $url ) {

    //         @$ch         = curl_init();
    //         curl_setopt( @$ch, CURLOPT_URL, @$url );
    //         curl_setopt( @$ch, CURLOPT_RETURNTRANSFER, 1 );
    //         @$output = curl_exec( @$ch );
    //         curl_close( @$ch );
            
    //     return @$output;

    // }



    if ( @$_GET['req'] == TRUE ) {

        if ( @$_GET['req'] == 'pegawai' ) {

            if ( @$_GET['api'] == TRUE ) {

                if ( @$_GET['api'] == 'All' ) {

                    @$rest_api = query (" SELECT * FROM Tbl_Pegawai ORDER BY Id DESC ");
                    echo json_encode( @$rest_api );

                } elseif ( @$_GET['api'] == 'AllId' ) {

                    if ( @$_GET['Id'] == TRUE ) {

                        @$rest_api = queryid (" SELECT * FROM Tbl_Pegawai WHERE Id = '". @$_GET['Id'] ."' ORDER BY Id DESC ");

                        if ( @$rest_api ) {

                            echo json_encode( @$rest_api );

                        } else {

                            @$datas = [
                                'Req'   => '404',
                                'Msg'   => 'Data ID Belum Ada',
                            ];

                            echo json_encode( @$datas );

                        }

                    } else {

                        @$datas = [
                            'Req'   => '400',
                            'Msg'   => 'Not Found ID',
                        ];

                        echo json_encode( @$datas );

                    }

                } else {

                    @$datas = [
                        'Req'   => '404',
                        'Msg'   => 'Respon Not Found',
                    ];

                    echo json_encode( @$datas );

                }

            } else {

                @$datas = [
                    'Req'   => '404',
                    'Msg'   => 'Request Not Found',
                ];

                echo json_encode( @$datas );

            }

        } elseif ( @$_GET['req'] == 'absensi' ) {

            if ( @$_GET['api'] == TRUE ) {

                if ( @$_GET['api'] == 'All' ) {

                    @$rest_api = query (" SELECT * FROM Tbl_Absensi ORDER BY Id DESC ");
                    echo json_encode( @$rest_api );
                    
                } elseif ( @$_GET['api'] == 'Insert' ) {

                    @$data = [
                        'Tgl'           => @$_POST['Tgl'], 
                        'Jam'           => @$_POST['Jam'], 
                        'Ket'           => @$_POST['Ket'], 
                        // 'Barcode'       => str_replace(" ", "", @$_POST['Barcode']), 
                        'Barcode'       => date('YmdHis'), 
                        'Id_Pegawai'    => @$_POST['Id_Pegawai'], 
                    ];

                    @$query = @$connection -> prepare( 
                            "
                                INSERT INTO Tbl_Absensi (
                                    Tgl, Jam, Ket, Barcode, Id_Pegawai
                                ) VALUES (
                                    :Tgl, :Jam, :Ket, :Barcode, :Id_Pegawai
                                )
                            "
                    ) -> execute ( @$data );

                    if ( @$query ) {
                        
                        @$penyimpanan   = "../barcode/";
                        @$code          = @$data['Barcode'] . ".png";
                        @$isi           = str_replace(" ", "", @$code); 
                        if ( !file_exists( @$penyimpanan . @$isi ) ) { 
                            QRcode::png( @$isi, @$penyimpanan . @$isi ); 
                        }

                        @$datas = [
                            'Req'   => '200',
                            'Msg'   => 'Sukses',
                        ];

                        echo json_encode( @$datas );

                    } else {

                        @$datas = [
                            'Req'   => '400',
                            'Msg'   => 'Tidak Berhasil',
                        ];

                        echo json_encode( @$datas );

                    }

                }

            } else {

                @$datas = [
                    'Req'   => '404',
                    'Msg'   => 'Request Not Found',
                ];

                echo json_encode( @$datas );

            }

        } else {

            @$datas = [
                'Req'   => '404',
                'Msg'   => 'Path Not Found',
            ];

            echo json_encode( @$datas );

        }

    }


    

    // @$base_api      = base_url() . '?req=pegawai&api=All';
    // @$api_curl      = Api_Curl( @$base_api );
    
    
    // @$request_data = json_decode( @$api_curl, TRUE );