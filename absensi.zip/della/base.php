<?php



    date_default_timezone_set('Asia/Jakarta');


    function base_url() {

        @$base = 'http://della.test/';
        return @$base;

    }



    function nama_url() {

        @$nama = 'Aplikasi Absensi';
        return @$nama;

    }


    
    try {

		@$connection = new PDO( 'mysql:host=localhost; dbname=Absensi', 'root', '' );
        @$connection -> exec( 'set names utf8' );
        @$connection -> setAttribute( PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION );

    } catch ( PDOException $error ) {

        print "Koneksi Database : " . $error->getMessage() . "<br/>";
		die();

    }




    function query ( $data_tampil ) {

        global $connection;

            $row_data       = $connection->prepare( $data_tampil );
            $row_data->execute();
            $datas          = [];
            while ( $data_tampil = $row_data->fetch(PDO::FETCH_OBJ) ) :
                $datas[]    = $data_tampil;
            endwhile;
        
        return $datas;

    }

    function queryid ( $data_tampil ) {

        global $connection;

            $row_data       = $connection->prepare( $data_tampil );
            $row_data->execute();
            $data_tampil    = $row_data->fetch(PDO::FETCH_OBJ);
            $datas[]        = $data_tampil;
        
        return $data_tampil;

    }
    
    function Query_Master ( $data, $path ) {

        global $connection;

            if ( @$path == 'Insert' ) {

                @$query = @$connection -> prepare( 
                        "
                            INSERT INTO Tbl_Pegawai (
                                Nama, Email, Username, Password, Jabatan, Divisi, TempatLahir, TglLahir, Status, TglMasuk
                            ) VALUES (
                                :Nama, :Email, :Username, :Password, :Jabatan, :Divisi, :TempatLahir, :TglLahir, :Status, :TglMasuk
                            )
                        "
                ) -> execute ( @$data );

            } elseif ( @$path == 'Update' ) {

                @$query = @$connection -> prepare( 
                        "
                            UPDATE Tbl_Pegawai SET
                                Nama            = :Nama,
                                Email           = :Email, 
                                Username        = :Username, 
                                Password        = :Password,
                                Jabatan         = :Jabatan,     
                                Divisi          = :Divisi,
                                TempatLahir     = :TempatLahir, 
                                TglLahir        = :TglLahir, 
                                Status          = :Status,
                                TglMasuk        = :TglMasuk
                            WHERE Id            = :Id
                        "
                ) -> execute ( @$data );

            } elseif ( @$path == 'Delete' ) {

                @$query = @$connection -> prepare( 
                        "
                            DELETE FROM Tbl_Pegawai
                            WHERE Id = :Id
                        "
                ) -> execute ( @$data );

            }

            if ( @$query == TRUE ) {

                @$respon    = '200';

            } else {

                @$respon    = '400';

            }

        return @$respon;

    }

    function Query_Absensi ( $data, $path ) {

        global $connection;

            if ( @$path == 'Insert' ) {

                @$query = @$connection -> prepare( 
                        "
                            INSERT INTO Tbl_Absensi (
                                Tgl, Jam, Ket, Barcode, Id_Pegawai
                            ) VALUES (
                                :Tgl, :Jam, :Ket, :Barcode, :Id_Pegawai
                            )
                        "
                ) -> execute ( @$data );

            } elseif ( @$path == 'Update' ) {

                @$query = @$connection -> prepare( 
                        "
                            UPDATE Tbl_Absensi SET
                                Tgl         = :Tgl,
                                Jam         = :Jam, 
                                Ket         = :Ket
                            WHERE Id        = :Id
                            AND Id_Pegawai  = :Id_Pegawai
                        "
                ) -> execute ( @$data );

            } elseif ( @$path == 'Delete' ) {

                @$query = @$connection -> prepare( 
                        "
                            DELETE FROM Tbl_Absensi
                            WHERE Id        = :Id
                            AND Id_Pegawai  = :Id_Pegawai
                        "
                ) -> execute ( @$data );

            }

            if ( @$query == TRUE ) {

                @$respon    = '200';

            } else {

                @$respon    = '400';

            }

        return @$respon;

    }




    require_once __DIR__ . '/assets/barcode/qrlib.php';

    

    