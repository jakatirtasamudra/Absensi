<div class="content-wrapper">
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>
                        Beranda
                    </h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item">
                            <a href="<?= base_url(); ?>">
                                Beranda
                            </a>
                        </li>
                        <li class="breadcrumb-item">
                            <a href="<?= base_url(); ?>?Mod=Master">
                                Data Master
                            </a>
                        </li>
                        <li class="breadcrumb-item active">
                            Master
                        </li>
                    </ol>
                </div>
            </div>
        </div>
    </section>
    <section class="content">
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">
                    Data Master
                </h3>
            </div>
            <div class="card-body">
                <table id="example1" class="table table-bordered table-striped text-center">
                    <thead class="bg-warning">
                        <tr>
                            <th>Nomor</th>
                            <th>Nama Lengkap</th>
                            <th>Tgl Lahir</th>
                            <th>Email</th>
                            <th>Jabatan</th>
                            <th>Divisi</th>
                            <th>Tgl Masuk</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                            @$nomor = '1';
                            @$request_data = query (" SELECT * FROM Tbl_Pegawai WHERE Id = '". @$session_data->Id ."' ORDER BY Id DESC ");
                                foreach ( @$request_data AS $data => $request ) :
                        ?>
                        <tr>
                            <td>
                                <?= @$nomor++; ?>
                            </td>
                            <td>
                                <?= @$request->Nama; ?>
                            </td>
                            <td>
                                <?= @$request->TempatLahir; ?>, <?= @$request->TglLahir; ?>
                            </td>
                            <td>
                                <?= @$request->Email; ?>
                            </td>
                            <td>
                                <?= @$request->Jabatan; ?>
                            </td>
                            <td>
                                <?= @$request->Divisi; ?>
                            </td>
                            <td>
                                <?= @$request->TglMasuk; ?>
                            </td>
                            <td>
                                <?php 
                                    if ( @$request->Status == 'Y' ) {
                                        echo 'Aktif';
                                    } else {
                                        echo 'Tidak Aktif';
                                    }
                                ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </section>
</div>