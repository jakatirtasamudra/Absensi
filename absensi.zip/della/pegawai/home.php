<div class="content-wrapper">
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>
                        Beranda
                    </h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item">
                            <a href="<?= base_url(); ?>">
                                Beranda
                            </a>
                        </li>
                        <li class="breadcrumb-item active">
                            Home
                        </li>
                    </ol>
                </div>
            </div>
        </div>
    </section>
    <section class="content">
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">
                    Selamat Datang Di Aplikasi <?= nama_url(); ?>
                </h3>
                <div class="card-tools">
                    <button type="button" class="btn btn-tool" data-card-widget="collapse" title="Collapse">
                        <i class="fas fa-minus"></i>
                    </button>
                    <button type="button" class="btn btn-tool" data-card-widget="remove" title="Remove">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
            </div>
            <div class="card-body">
                Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been
                the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley
                of type and scrambled it to make a type specimen book. It has survived not only five centuries,
                but also the leap into electronic typesetting, remaining essentially unchanged. It was
                popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages,
                and more recently with desktop publishing software like Aldus PageMaker including versions of
                Lorem Ipsum.
            </div>
        </div>
    </section>
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-3 col-sm-6 col-12">
                    <div class="info-box">
                        <span class="info-box-icon bg-info">
                            <i class="far fa-envelope"></i>
                        </span>
                        <div class="info-box-content">
                            <span class="info-box-text">
                                Admin Aktif
                            </span>
                            <span class="info-box-number">
                                1
                            </span>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6 col-12">
                    <div class="info-box">
                        <span class="info-box-icon bg-success">
                            <i class="far fa-flag"></i>
                        </span>
                        <div class="info-box-content">
                            <span class="info-box-text">
                                Data Karyawan
                            </span>
                            <span class="info-box-number">
                                410
                            </span>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6 col-12">
                    <div class="info-box">
                        <span class="info-box-icon bg-warning">
                            <i class="far fa-copy"></i>
                        </span>
                        <div class="info-box-content">
                            <span class="info-box-text">
                                Data Jabatan
                            </span>
                            <span class="info-box-number">
                                13
                            </span>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6 col-12">
                    <div class="info-box">
                        <span class="info-box-icon bg-danger">
                            <i class="far fa-star"></i>
                        </span>
                        <div class="info-box-content">
                            <span class="info-box-text">
                                Data Absensi
                            </span>
                            <span class="info-box-number">
                                100
                            </span>
                        </div>
                    </div>
                </div>
            </div>
    </section>
</div>