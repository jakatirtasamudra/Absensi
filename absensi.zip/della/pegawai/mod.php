<?php


    if ( @$_GET['Mod'] == 'Master' ) {

        require_once __DIR__ . '/master.php';

    } elseif ( @$_GET['Mod'] == 'Laporan' ) {

        require_once __DIR__ . '/laporan.php';

    } else {

        require_once __DIR__ . '/home.php';

    }