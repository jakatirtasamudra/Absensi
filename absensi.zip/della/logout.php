<?php


    ob_start();
    session_start();


    require_once __DIR__ . '/base.php';


    @$_SESSION = array();
    session_destroy();

    
    echo "<script>
            alert('Berhasil Logout');
            document.location.href = '". base_url() ."';
        </script>";