<?php



    ob_start();
    session_start();


    require_once __DIR__ . '/base.php';

    
    if ( isset ( $_SESSION['Id'] ) ) {
        
        if ( @$_SESSION['Status'] == 'Admin' ) {

            require_once __DIR__ . '/admin/index.php';

        } elseif ( @$_SESSION['Status'] == 'Pegawai' ) {

            require_once __DIR__ . '/pegawai/index.php';

        } else {

            require_once __DIR__ . '/login.php';

        }
        
    } else {

        require_once __DIR__ . '/login.php';

    }